import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


path =r"C:\Users\TOSHIBA-PC\Desktop\diabetes.csv"
names=["a","b","c","d","e","f","g","h","target"]
print(path)
data=pd.read_csv(path , names=names)
print(data.shape)
X=data.iloc[:, :8] .values
y=data.iloc[ :,8].values
print(X.shape)
print(y.shape)
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2898,random_state=1)

print(X_test.shape)
#print(y_test.shape)

from sklearn.neighbors import KNeighborsClassifier
model=KNeighborsClassifier(n_neighbors=17)
                           
model.fit(X_train,y_train)

y_pred=model.predict(X_test)
##y_pred1=model.predict([[6,183,40,32,160,543,0,0.537]])#this is new data given to the ml model
##print(y_pred1,"= predict_data")

print(y_pred)
##print(y_pred.shape)

from sklearn.metrics import accuracy_score
#print("accuracy:",accuracy_score(y_test,y_pred)*100)

from sklearn.metrics import confusion_matrix
#n="accuracy:",confusion_matrix(y_test,y_pred)
#print(n)

